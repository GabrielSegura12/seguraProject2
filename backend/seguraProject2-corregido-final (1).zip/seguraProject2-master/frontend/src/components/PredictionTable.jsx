import React from 'react';
import StyledTable from './StyledTable';

const PredictionTable = ({ predictions = [] }) => {
  const columns = [
    { key: 'code', label: 'Código producto', type: 'highlight', align: 'left' },
    { key: 'productName', label: 'Producto', align: 'left' },
    { key: 'category', label: 'Categoría', align: 'left' },
    {
      key: 'historicalAverage',
      label: 'Promedio histórico (unid.)',
      align: 'right',
      render: (value) => Number(value).toFixed(2),
    },
    {
      key: 'nextPeriodPrediction',
      label: 'Predicción siguiente periodo (unid.)',
      type: 'highlight',
      align: 'right',
      render: (value) => Number(value).toFixed(2),
    },
    {
      key: 'trend',
      label: 'Tendencia',
      align: 'center',
      render: (value) => (value === 'up' ? 'Alza' : value === 'down' ? 'Baja' : 'Estable'),
    },
  ];

  return <StyledTable data={predictions} columns={columns} title="Resultados de la predicción por producto" />;
};

export default PredictionTable;
