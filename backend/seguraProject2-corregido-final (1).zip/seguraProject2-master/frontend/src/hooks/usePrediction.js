import { useState } from 'react';
import api from '../api/axios';

export const usePrediction = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const algorithms = [
    {
      id: 'linear_regression',
      name: 'Regresión Lineal',
      description: 'Modelo lineal que identifica tendencias generales en los datos históricos.',
    },
    {
      id: 'random_forest',
      name: 'Random Forest',
      description: 'Combina múltiples árboles de regresión para generar predicciones más robustas.',
    },
    {
      id: 'xgboost',
      name: 'XGBoost',
      description: 'Algoritmo de boosting que construye modelos de forma secuencial para reducir el error.',
    },
  ];

  const generatePredictions = async (data, algorithm) => {
    setIsAnalyzing(true);
    try {
      const response = await api.post('/predictions/evaluate', {
        algorithm,
        records: data,
      });
      return response.data;
    } finally {
      setIsAnalyzing(false);
    }
  };

  return { isAnalyzing, generatePredictions, algorithms };
};
