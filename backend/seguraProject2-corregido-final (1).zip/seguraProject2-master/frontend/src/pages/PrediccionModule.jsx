import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { theme } from '../styles/themes';
import StyledButton from '../components/StyledButton';
import PredictionTable from '../components/PredictionTable';
import { useFileHandler } from '../hooks/useFileHandler';
import { usePrediction } from '../hooks/usePrediction';
import { downloadResults } from '../utils/predictionUtils';

const ALGORITHM_LABELS = {
  linear_regression: 'Regresión Lineal',
  random_forest: 'Random Forest',
  xgboost: 'XGBoost',
};

const MetricsTable = ({ metrics, bestModel }) => {
  const rows = Object.entries(metrics || {}).map(([algorithm, values]) => ({
    algorithm,
    name: ALGORITHM_LABELS[algorithm],
    ...values,
  }));

  if (!rows.length) return null;

  return (
    <div style={{ marginTop: theme.spacing.xl }}>
      <h3 style={{ color: theme.colors.text.primary, marginBottom: theme.spacing.md }}>
        Evaluación de los algoritmos
      </h3>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', background: '#fff' }}>
          <thead>
            <tr style={{ background: theme.colors.primary.main, color: '#fff' }}>
              {['Algoritmo', 'MAE', 'RMSE', 'MAPE (%)', 'R²'].map((label) => (
                <th key={label} style={{ padding: '12px', textAlign: label === 'Algoritmo' ? 'left' : 'right' }}>
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.algorithm} style={{ borderBottom: `1px solid ${theme.colors.border.light}` }}>
                <td style={{ padding: '12px', fontWeight: row.algorithm === bestModel ? 700 : 400 }}>
                  {row.name}{row.algorithm === bestModel ? ' — mejor desempeño global' : ''}
                </td>
                <td style={{ padding: '12px', textAlign: 'right' }}>{row.mae.toFixed(4)}</td>
                <td style={{ padding: '12px', textAlign: 'right' }}>{row.rmse.toFixed(4)}</td>
                <td style={{ padding: '12px', textAlign: 'right' }}>{row.mape.toFixed(4)}</td>
                <td style={{ padding: '12px', textAlign: 'right' }}>{row.r2.toFixed(4)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{
        marginTop: theme.spacing.md,
        padding: theme.spacing.md,
        borderRadius: theme.borderRadius.md,
        background: theme.colors.success.background || '#ecfdf3',
        color: theme.colors.success.main,
        border: `1px solid ${theme.colors.success.main}`,
      }}>
        Evaluación realizada con el 100 % de los registros mediante validación cruzada K-Fold de 5 pliegues.
        El modelo final se entrena nuevamente con todos los registros para generar la predicción del siguiente periodo.
      </div>
    </div>
  );
};

const PredictionModule = () => {
  const { user, logout } = useAuth();
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('linear_regression');
  const [predictionResult, setPredictionResult] = useState(null);

  const { fileName, columns, data, error, setError, handleFileUpload } = useFileHandler();
  const { isAnalyzing, generatePredictions, algorithms } = usePrediction();

  const handlePrediction = async () => {
    if (!data.length) {
      setError('Por favor, carga un archivo de ventas antes de ejecutar el modelo.');
      return;
    }
    try {
      setError(null);
      const result = await generatePredictions(data, selectedAlgorithm);
      setPredictionResult(result);
    } catch (err) {
      const detail = err?.response?.data?.detail;
      setError(detail || 'No se pudo ejecutar el modelo predictivo. Revisa los datos y vuelve a intentarlo.');
    }
  };

  if (!user) return <div>Cargando...</div>;

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{
        width: '280px',
        background: theme.colors.primary.gradient,
        color: theme.colors.text.white,
        padding: theme.spacing.xl,
        position: 'fixed',
        height: '100vh',
        left: 0,
        top: 0,
      }}>
        <h2 style={{ marginBottom: theme.spacing.xl }}>Modelo de Predicción</h2>
        <div style={{ padding: theme.spacing.md, background: theme.colors.overlay.light, borderRadius: theme.borderRadius.lg }}>
          <strong>{user.full_name || user.username}</strong>
          <div style={{ opacity: 0.8, fontSize: theme.typography.sizes.sm }}>{user.email}</div>
        </div>
        <StyledButton variant="secondary" fullWidth onClick={logout} style={{ marginTop: theme.spacing.xl }}>
          Cerrar sesión
        </StyledButton>
      </aside>

      <main style={{
        flex: 1,
        marginLeft: '280px',
        padding: theme.spacing.xl,
        background: theme.colors.background.primary,
        minHeight: '100vh',
      }}>
        <div style={{ maxWidth: '1180px', margin: '0 auto' }}>
          <h1 style={{ color: theme.colors.text.primary }}>Módulo de Predicción</h1>
          <p style={{ color: theme.colors.text.secondary }}>
            Carga los registros históricos, selecciona un algoritmo y genera la predicción de ventas del siguiente periodo.
          </p>

          <section style={{ background: theme.colors.background.secondary, padding: theme.spacing.xl, borderRadius: theme.borderRadius.xl, boxShadow: theme.colors.shadow.main }}>
            <div style={{
              border: `2px dashed ${theme.colors.border.main}`,
              borderRadius: theme.borderRadius.lg,
              padding: theme.spacing['3xl'],
              textAlign: 'center',
              background: theme.colors.background.primary,
            }}>
              <h3>{fileName || 'Arrastra tu archivo aquí'}</h3>
              <p style={{ color: theme.colors.text.secondary }}>Formatos permitidos: Excel (.xlsx, .xls) o CSV</p>
              <input id="fileInput" type="file" accept=".csv,.xlsx,.xls" onChange={handleFileUpload} style={{ display: 'none' }} />
              <StyledButton variant="primary" onClick={() => document.getElementById('fileInput').click()}>
                Seleccionar archivo
              </StyledButton>
              {fileName && <div style={{ marginTop: theme.spacing.md, color: theme.colors.success.main }}>{fileName} cargado correctamente</div>}
            </div>
            {error && <div style={{ marginTop: theme.spacing.md, color: theme.colors.error.main }}>{error}</div>}
          </section>

          {data.length > 0 && (
            <section style={{ marginTop: theme.spacing.xl, background: theme.colors.background.secondary, padding: theme.spacing.xl, borderRadius: theme.borderRadius.xl, boxShadow: theme.colors.shadow.main }}>
              <h3>Selecciona un algoritmo de predicción</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: theme.spacing.md }}>
                {algorithms.map((algo) => (
                  <button
                    key={algo.id}
                    type="button"
                    onClick={() => setSelectedAlgorithm(algo.id)}
                    style={{
                      textAlign: 'left',
                      padding: theme.spacing.lg,
                      borderRadius: theme.borderRadius.lg,
                      border: `2px solid ${selectedAlgorithm === algo.id ? theme.colors.primary.main : theme.colors.border.main}`,
                      background: selectedAlgorithm === algo.id ? theme.colors.hover.primary : theme.colors.background.primary,
                      cursor: 'pointer',
                    }}
                  >
                    <strong style={{ color: theme.colors.text.primary }}>{algo.name}</strong>
                    <p style={{ marginBottom: 0, color: theme.colors.text.secondary }}>{algo.description}</p>
                  </button>
                ))}
              </div>

              <div style={{ marginTop: theme.spacing.lg, padding: theme.spacing.md, background: theme.colors.background.primary, borderRadius: theme.borderRadius.md, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' }}>
                <span>Registros detectados: <strong>{data.length}</strong></span>
                <span>Columnas detectadas: <strong>{columns.length}</strong></span>
                <span>Algoritmo seleccionado: <strong>{ALGORITHM_LABELS[selectedAlgorithm]}</strong></span>
              </div>

              <StyledButton variant="primary" fullWidth onClick={handlePrediction} disabled={isAnalyzing} style={{ marginTop: theme.spacing.lg }}>
                {isAnalyzing ? 'Evaluando modelos...' : 'Realizar predicción'}
              </StyledButton>
            </section>
          )}

          {predictionResult && (
            <section style={{ marginTop: theme.spacing.xl, background: theme.colors.background.secondary, padding: theme.spacing.xl, borderRadius: theme.borderRadius.xl, boxShadow: theme.colors.shadow.main }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: theme.spacing.md, flexWrap: 'wrap' }}>
                <div>
                  <h2 style={{ marginBottom: 0 }}>Resultados del modelo predictivo</h2>
                  <p style={{ color: theme.colors.text.secondary, marginTop: theme.spacing.xs }}>
                    Predicciones generadas con {ALGORITHM_LABELS[predictionResult.selected_algorithm]}.
                  </p>
                </div>
                <StyledButton variant="primary" onClick={() => downloadResults(predictionResult)}>Descargar Excel</StyledButton>
              </div>

              <PredictionTable predictions={predictionResult.predictions} />
              <MetricsTable metrics={predictionResult.metrics} bestModel={predictionResult.best_model} />
            </section>
          )}
        </div>
      </main>
    </div>
  );
};

export default PredictionModule;
