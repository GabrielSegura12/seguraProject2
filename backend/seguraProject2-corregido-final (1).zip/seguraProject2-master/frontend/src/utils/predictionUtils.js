import * as XLSX from 'xlsx';

export const downloadTemplate = () => {
  const templateData = [
    {
      ID: 1,
      fecha_venta: '2025-01-03',
      codigo_producto: 'PRD001',
      Producto: 'Mouse Logitech M185',
      'Código Categoría': 'CAT001',
      Categoría: 'Periféricos',
      'Precio Unitario (S/.)': 65,
      Cantidad: 3,
      'Stock Inicial': 120,
      'Stock Final': 117,
      'Total Venta (S/.)': 195,
    },
  ];
  const worksheet = XLSX.utils.json_to_sheet(templateData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Ventas');
  XLSX.writeFile(workbook, 'plantilla_prediccion_ventas.xlsx');
};

export const downloadResults = (predictionResult) => {
  if (!predictionResult?.predictions) return;
  const resultData = predictionResult.predictions.map((item) => ({
    codigo_producto: item.code,
    producto: item.productName,
    categoria: item.category,
    promedio_historico: item.historicalAverage,
    prediccion_siguiente_periodo: item.nextPeriodPrediction,
    tendencia: item.trend === 'up' ? 'Alza' : item.trend === 'down' ? 'Baja' : 'Estable',
  }));
  const metricsData = Object.entries(predictionResult.metrics).map(([algorithm, metrics]) => ({
    algoritmo: algorithm,
    MAE: metrics.mae,
    RMSE: metrics.rmse,
    'MAPE (%)': metrics.mape,
    R2: metrics.r2,
  }));
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(resultData), 'Predicciones');
  XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(metricsData), 'Metricas');
  XLSX.writeFile(workbook, 'resultados_modelo_predictivo.xlsx');
};
