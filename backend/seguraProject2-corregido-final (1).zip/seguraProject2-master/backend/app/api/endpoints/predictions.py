from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.prediction_service import evaluate_and_predict

router = APIRouter(prefix="/predictions", tags=["predictions"])


class PredictionRequest(BaseModel):
    algorithm: str = Field(pattern="^(linear_regression|random_forest|xgboost)$")
    records: list[dict[str, Any]]


@router.post("/evaluate")
def evaluate_predictions(payload: PredictionRequest):
    try:
        return evaluate_and_predict(payload.records, payload.algorithm)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"No se pudo ejecutar la predicción: {exc}") from exc
