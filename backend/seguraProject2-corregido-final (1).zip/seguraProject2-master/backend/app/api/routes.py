from fastapi import APIRouter
from app.api.endpoints import predictions, users

router = APIRouter()
router.include_router(users.router)
router.include_router(predictions.router)
