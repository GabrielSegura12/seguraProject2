from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBRegressor


COLUMN_ALIASES = {
    "fecha_venta": {"fecha", "fecha_venta", "fecha_de_venta"},
    "codigo_producto": {"codigo_producto", "codigo_de_producto", "cod_producto"},
    "producto": {"producto", "nombre_producto", "nombre_del_producto"},
    "codigo_categoria": {"codigo_categoria", "codigo_de_categoria", "cod_categoria"},
    "categoria": {"categoria", "nombre_categoria"},
    "precio_unitario": {"precio", "precio_unitario", "precio_s", "precio_unitario_s"},
    "cantidad": {"cantidad", "cantidad_vendida", "cant", "cant_vendida"},
    "stock_inicial": {"stock_inicial"},
    "stock_final": {"stock_final"},
    "total_venta": {"total_venta", "total_venta_s"},
}


def _normalize_name(value: Any) -> str:
    text = str(value).strip().lower()
    text = "".join(c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return text


def _canonicalize_dataframe(records: list[dict[str, Any]]) -> pd.DataFrame:
    if not records:
        raise ValueError("El conjunto de datos está vacío.")

    df = pd.DataFrame(records)
    normalized = {_normalize_name(col): col for col in df.columns}
    rename_map: dict[str, str] = {}

    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in normalized:
                rename_map[normalized[alias]] = canonical
                break

    df = df.rename(columns=rename_map)
    required = ["fecha_venta", "codigo_producto", "producto", "categoria", "precio_unitario", "cantidad", "stock_inicial"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError("Faltan columnas requeridas: " + ", ".join(missing))

    df["fecha_venta"] = pd.to_datetime(df["fecha_venta"], errors="coerce")
    for col in ["precio_unitario", "cantidad", "stock_inicial"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if "codigo_categoria" not in df.columns:
        df["codigo_categoria"] = df["categoria"].astype(str)

    df = df.dropna(subset=["fecha_venta", "codigo_producto", "producto", "categoria", "precio_unitario", "cantidad", "stock_inicial"])
    if len(df) < 10:
        raise ValueError("Se requieren al menos 10 registros válidos para evaluar los modelos.")

    # Variables temporales. No se usa stock_final porque filtra la variable objetivo:
    # stock_final = stock_inicial - cantidad vendida.
    df["anio"] = df["fecha_venta"].dt.year
    df["mes"] = df["fecha_venta"].dt.month
    df["dia"] = df["fecha_venta"].dt.day
    df["dia_anio"] = df["fecha_venta"].dt.dayofyear
    return df.sort_values("fecha_venta").reset_index(drop=True)


NUMERIC_FEATURES = ["precio_unitario", "stock_inicial", "anio", "mes", "dia", "dia_anio"]
CATEGORICAL_FEATURES = ["codigo_producto", "producto", "codigo_categoria", "categoria"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
TARGET = "cantidad"


def _build_pipeline(algorithm: str) -> Pipeline:
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    preprocessor = ColumnTransformer([
        ("numeric", numeric, NUMERIC_FEATURES),
        ("categorical", categorical, CATEGORICAL_FEATURES),
    ])

    models = {
        "linear_regression": LinearRegression(),
        "random_forest": RandomForestRegressor(
            n_estimators=300,
            random_state=42,
            min_samples_leaf=2,
            n_jobs=-1,
        ),
        "xgboost": XGBRegressor(
            n_estimators=300,
            learning_rate=0.04,
            max_depth=3,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="reg:squarederror",
            random_state=42,
            n_jobs=2,
        ),
    }
    if algorithm not in models:
        raise ValueError("Algoritmo no válido.")
    return Pipeline([("preprocessor", preprocessor), ("model", models[algorithm])])


def _metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    y_pred = np.maximum(0, y_pred)
    return {
        "mae": round(float(mean_absolute_error(y_true, y_pred)), 4),
        "rmse": round(float(math.sqrt(mean_squared_error(y_true, y_pred))), 4),
        "mape": round(float(mean_absolute_percentage_error(y_true, y_pred) * 100), 4),
        "r2": round(float(r2_score(y_true, y_pred)), 4),
    }


def evaluate_and_predict(records: list[dict[str, Any]], selected_algorithm: str) -> dict[str, Any]:
    df = _canonicalize_dataframe(records)
    X = df[FEATURES]
    y = df[TARGET].astype(float).to_numpy()

    # Los 120 registros participan en una validación cruzada de 5 pliegues.
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    all_metrics: dict[str, dict[str, float]] = {}
    fitted_models: dict[str, Pipeline] = {}

    for algorithm in ["linear_regression", "random_forest", "xgboost"]:
        pipeline = _build_pipeline(algorithm)
        cv_pred = cross_val_predict(pipeline, X, y, cv=cv, n_jobs=None)
        all_metrics[algorithm] = _metrics(y, cv_pred)
        pipeline.fit(X, y)  # modelo final entrenado con el 100 % de los registros
        fitted_models[algorithm] = pipeline

    selected_model = fitted_models[selected_algorithm]
    predictions = []
    for product_code, group in df.groupby("codigo_producto", sort=True):
        group = group.sort_values("fecha_venta")
        latest = group.iloc[-1].copy()
        next_date = latest["fecha_venta"] + pd.DateOffset(months=1)
        future = pd.DataFrame([{
            "precio_unitario": latest["precio_unitario"],
            "stock_inicial": latest.get("stock_final", latest["stock_inicial"]),
            "anio": next_date.year,
            "mes": next_date.month,
            "dia": next_date.day,
            "dia_anio": next_date.dayofyear,
            "codigo_producto": latest["codigo_producto"],
            "producto": latest["producto"],
            "codigo_categoria": latest["codigo_categoria"],
            "categoria": latest["categoria"],
        }])
        pred = max(0.0, float(selected_model.predict(future[FEATURES])[0]))
        historical_avg = float(group["cantidad"].mean())
        ratio = pred / historical_avg if historical_avg > 0 else 1.0
        trend = "up" if ratio > 1.10 else "down" if ratio < 0.90 else "stable"
        predictions.append({
            "code": str(product_code),
            "productName": str(latest["producto"]),
            "category": str(latest["categoria"]),
            "historicalAverage": round(historical_avg, 2),
            "nextPeriodPrediction": round(pred, 2),
            "trend": trend,
        })

    # Mejor desempeño global: ranking promedio (menor en errores, mayor en R2).
    algorithms = list(all_metrics.keys())
    ranks = {a: 0 for a in algorithms}
    for metric in ["mae", "rmse", "mape"]:
        for rank, algorithm in enumerate(sorted(algorithms, key=lambda a: all_metrics[a][metric]), 1):
            ranks[algorithm] += rank
    for rank, algorithm in enumerate(sorted(algorithms, key=lambda a: all_metrics[a]["r2"], reverse=True), 1):
        ranks[algorithm] += rank
    best_model = min(ranks, key=ranks.get)

    return {
        "selected_algorithm": selected_algorithm,
        "records_analyzed": int(len(df)),
        "valid_records_percentage": 100.0,
        "validation_method": "K-Fold de 5 pliegues",
        "metrics": all_metrics,
        "best_model": best_model,
        "predictions": predictions,
    }
