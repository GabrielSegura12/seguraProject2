# Versión corregida para la tesis

Esta versión reemplaza las funciones incorrectas de suavizado exponencial y ARIMA por implementaciones reales de:

- Regresión Lineal
- Random Forest Regressor
- XGBoost Regressor

## Evaluación

Los tres algoritmos se evalúan con validación cruzada K-Fold de 5 pliegues. De esta manera, el 100 % de los registros participa en el entrenamiento y la validación. Después de la evaluación, cada modelo se vuelve a entrenar con todos los registros para generar la predicción del siguiente periodo.

La interfaz muestra:

- nombres reales de los productos;
- promedio histórico;
- predicción del siguiente periodo;
- tendencia;
- MAE, RMSE, MAPE y R² de los tres algoritmos;
- algoritmo con mejor desempeño global.

## Ejecución con Docker

Desde la carpeta raíz del proyecto:

```bash
docker compose up --build
```

Luego abre:

- Frontend: http://localhost:5173
- API: http://localhost:8000/docs

## Columnas esperadas

El archivo Excel puede usar las columnas del dataset de la tesis, incluyendo:

- `fecha_venta`
- `codigo_producto`
- `Producto`
- `Código Categoría`
- `Categoría`
- `Precio Unitario (S/.)`
- `Cantidad`
- `Stock Inicial`
- `Stock Final`
- `Total Venta (S/.)`

`Stock Final` no se usa como variable predictora, porque se deriva de `Stock Inicial - Cantidad` y usarla produciría fuga de información.
